document.getElementById('fsiForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    // Collect input values
    const plot_area = parseFloat(document.getElementById('plot_area').value);
    const permissible_fsi = parseFloat(document.getElementById('permissible_fsi').value);
    const tdr = parseFloat(document.getElementById('tdr').value);
    const ancillary_fsi = parseFloat(document.getElementById('ancillary_fsi').value);

    // Validate inputs
    if (!validateInputs(plot_area, permissible_fsi, tdr, ancillary_fsi)) {
        return; // If validation fails, stop the execution
    }

    try {
        // Send data to the backend
        const response = await fetch('/calculate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ plot_area, permissible_fsi, tdr, ancillary_fsi }),
        });

        const data = await response.json();

        // Update the results
        document.getElementById('total_fsi').innerText = data.total_fsi.toFixed(2) + " ";
        document.getElementById('built_up_area').innerText = data.built_up_area.toFixed(2) + " sq. m";
        document.getElementById('carpet_area').innerText = data.carpet_area.toFixed(2) + " sq. m";
    } catch (error) {
        console.error('Error:', error);
        alert('Mahesh! Failed to calculate. Please try again.');
    }
});

// Function to validate inputs
function validateInputs(plotArea, permissibleFsi, tdr, ancillaryFsi) {
    if (isNaN(plotArea) || isNaN(permissibleFsi) || isNaN(tdr) || isNaN(ancillaryFsi)) {
        alert("Please enter valid numeric values.");
        return false;
    }

    // Optionally, ensure values are within a specific range
    if (plotArea < 0 || permissibleFsi < 0 || tdr < 0 || ancillaryFsi < 0) {
        alert("Values must be greater than 0.");
        return false;
    }

    return true;
}
